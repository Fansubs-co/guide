	----------------------------------------------------------------------------------------------------------------
	--[[ ( c ) Copyright 2012 - 2019, Vict8r, Karalaura, NatsuoKE & Itachi Akatsuki				  				]]--
	----------------------------------------------------------------------------------------------------------------
	--[[ El archivo Effector-newlib-3.6.lua  ha sido creado con la intención de poder almacenar todas esas variables
	que usamos constantemente en nuestros efectos y ediciones de texto, también aquellas funciones que diseñamos por
	comodidad o necesidad de nuestras creaciones. Se debe tener muy presente que, todo lo que sea almacenado en este
	archivo afectará directamente al funcionamiento correcto del Kara Effector, por lo que, si algo de lo almacenado
	o modificado genera un error, éste deberá ser reparado o eliminado, para que todo funcione de forma correcta. Se
	debe contar con unos conocimientos mínimos de programación en lenguaje LUA para poder crear o diseñar la mayoría
	de las funciones extras, externas al Kara Effector, que son necesarias para la invención de efectos considerados
	de nivel avanzado, así que gran parte de la responsabilidad del correcto funcionamiento del KE dependerá de todo
	lo que acá sea añadido/modificado.
	En caso de tener alguna duda o inquietud, no olvides ponerte en contacto con nosotros, y de ser posible, daremos
	pronta solución a tus cuestionamientos. Ahora contamos con nuevos canales de comunicación por los cuales podemos
	estar en contacto más seguido y hasta en tiempo real. --]]
	
	--> Kara Effector 3.6 legacy
	--> Contáctanos:
	
	--> [WhatsApp] Kara Effector: +57 320 863 14 72
	--> [Discord]  Kara Effector: discord.gg/YFP2zeY
	-->	http://www.facebook.com/karaeffector
	--> http://www.karaeffector.blogspot.com
	
	-- Effector-newlib-3.6.lua -------------------------------------------------------------------------------------
	Effector_NewLib_authors  = "Itachi Akatsuki"
	Effector_NewLib_testers  = "NatsuoKE & Vict8r"
	Effector_NewLib_version  = "1.0"
	Effector_NewLib_modified = "January 12th 2019"
	----------------------------------------------------------------------------------------------------------------
  
 	my_val = Rs( 200 )
